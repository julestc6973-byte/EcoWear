EcoWear - training images for Google Teachable Machine (Session 8 practical)
=========================================================================

Two folders, one per class. The names of the folders are the names to give the classes.

  EcoWear label     60 photos of our woven label and hang tag, close up, far away, turned and in
                    different light.
  No EcoWear label  71 photos of garments, creations, fabric and collars without our label.

How to train and connect the model (about 10 minutes)
1. Gather: open https://teachablemachine.withgoogle.com/ > Get Started > Image Project > Standard image model.
   Rename "Class 1" to "EcoWear label" and "Class 2" to "No EcoWear label" (keep this order:
   the website reads class 1 as the label).
   In each class click "Upload" and drop all the photos of the matching folder.
   Tip: add a few webcam photos of the labels of your own clothes to "No EcoWear label".
2. Train: click "Train Model" and keep the tab open until it finishes. Test it with the Preview panel.
3. Export: "Export Model" > "Upload (shareable link)" > "Upload my model". Copy the link.
   Paste it in myscripts.js, in the line  const MODEL_URL = "";  (keep the / at the end).
